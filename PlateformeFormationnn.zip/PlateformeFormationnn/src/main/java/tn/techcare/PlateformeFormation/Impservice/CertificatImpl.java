package tn.techcare.PlateformeFormation.Impservice;


import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Certificats;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.CertificatRepository;
import tn.techcare.PlateformeFormation.service.CertificatService;

 
@Service
@Transactional
public class CertificatImpl implements CertificatService {
	@Autowired
   private CertificatRepository certificatRepository ;
	@Override
	public MessageReponse AjoutCertificats(Certificats Certif) {
		// TODO Auto-generated method stub
		certificatRepository.save(Certif);
		return  new MessageReponse(true, Certif.getId_C()+ "Certificat ajouté ") ;
		}
	@Transactional
	@Override
	public List<Certificats> getAllCertificats() {		 
	 return     certificatRepository.findAll();
	         

	    }
	@Transactional
	@Override
	public MessageReponse ModifierCertificats(Certificats Certif) {
		// TODO Auto-generated method stub
		
		Certificats Certif2 = certificatRepository.findById(Certif.getId_C()).orElse(null);
		System.out.println(Certif2.getId_C());	

		if (Certif2!=null) 
		{
			   certificatRepository.save(Certif);
	           return new MessageReponse(true, "Certificat modifiée");
		}
		       return new MessageReponse(false , "Certificat introuvable");
	    }
	
	@Transactional
	@Override
	public MessageReponse SupprimerCertificats(int id_C) {
		// TODO Auto-generated method stub

	Certificats certificats = certificatRepository.findById(id_C).orElse(null) ;
       if(certificats== null) 
       {
       return new MessageReponse(false, "erreur , certificat introuvable");
       }
         certificatRepository.delete(certificats);
         return new MessageReponse(true, "operation delet effectue avec succes");

       }
	
}
