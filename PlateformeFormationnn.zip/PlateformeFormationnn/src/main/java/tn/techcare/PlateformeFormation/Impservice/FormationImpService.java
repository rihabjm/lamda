package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.FormationRepository;
import tn.techcare.PlateformeFormation.service.FormationService;
@Service
@Transactional
public class FormationImpService implements FormationService {
   
	@Autowired
  private  FormationRepository fromationRepository ;
	
	@Override
	public MessageReponse ajoutFormation(Formation formation) {
		fromationRepository.save(formation);
		return  new MessageReponse(true, formation.getIdformation()+ "formation est ajouter ") ;
	}

	@Override
	public List<Formation> getAllFormation() {
		// TODO Auto-generated method stub
		return (List<Formation>) fromationRepository.findAll();

	}

	
}
