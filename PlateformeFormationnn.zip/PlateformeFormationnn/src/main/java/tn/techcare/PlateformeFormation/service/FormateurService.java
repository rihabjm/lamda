package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.util.List;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;

 

public interface FormateurService {
	  public MessageReponse AjoutFormateur (String nom ,String prenom, String adresse, String mail,int telephone , Date dateNAisse   ,ImageModel image) ;
	  public List<Formateur> getAllFormateur();
      public MessageReponse ModifierFormateur(Formateur formateur) ;
	  public MessageReponse SupprimerFormateur(int id);
	  
		List<Formateur> getFormateurByNom(String nom ) ;
		List<Formateur> getFormateurByPrenom(String prenom ) ;
		List<Formateur>  getFormateurByAdresse(String adresse ) ;
		List<Formateur> getFormateurByMail(String mail ) ;
		List<Formateur> getFormateurByTelephone(int telephone ) ;
		List<Formateur> getFormateurByDateNAisse(Date datenais ) ;
}
