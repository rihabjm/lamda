package tn.techcare.PlateformeFormation.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Calendrier")
public class Calendrier {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_date;
	private Date db_date ;
	private int anne ;
	private int mois ;
	private int  jour ;
	private int trimestre ;
    private int semaine ;
	private String nomjour  ;
	private String nommois ;
	private String vacance ;
	private String weekend ;
	private String   evenement ;
	
	
    @OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "calendrier")
    private Formation formation;
	
	
	public int getId_date() {
		return id_date;
	}
	public void setId_date(int id_date) {
		this.id_date = id_date;
	}
	public Date getDb_date() {
		return db_date;
	}
	public void setDb_date(Date db_date) {
		this.db_date = db_date;
	}
	public int getAnne() {
		return anne;
	}
	public void setAnne(int anne) {
		this.anne = anne;
	}
	public int getMois() {
		return mois;
	}
	public void setMois(int mois) {
		this.mois = mois;
	}
	public int getJour() {
		return jour;
	}
	public void setJour(int jour) {
		this.jour = jour;
	}
	public int getTrimestre() {
		return trimestre;
	}
	public void setTrimestre(int trimestre) {
		this.trimestre = trimestre;
	}
	public int getSemaine() {
		return semaine;
	}
	public void setSemaine(int semaine) {
		this.semaine = semaine;
	}
	public String getNomjour() {
		return nomjour;
	}
	public void setNomjour(String nomjour) {
		this.nomjour = nomjour;
	}
	public String getNommois() {
		return nommois;
	}
	public void setNommois(String nommois) {
		this.nommois = nommois;
	}
	public String getVacance() {
		return vacance;
	}
	public void setVacance(String vacance) {
		this.vacance = vacance;
	}
	public String getWeekend() {
		return weekend;
	}
	public void setWeekend(String weekend) {
		this.weekend = weekend;
	}
	public String getEvenement() {
		return evenement;
	}
	public void setEvenement(String evenement) {
		this.evenement = evenement;
	}

	
}
