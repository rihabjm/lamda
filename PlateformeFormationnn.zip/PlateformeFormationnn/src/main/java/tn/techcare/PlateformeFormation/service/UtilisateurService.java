package tn.techcare.PlateformeFormation.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import tn.techcare.PlateformeFormation.model.Utilisateur;

public interface UtilisateurService  extends UserDetailsService {
	
	public List<Utilisateur> getutilisateur () ; 
	public UserDetails loadUserByUsername(String login) ;

}
