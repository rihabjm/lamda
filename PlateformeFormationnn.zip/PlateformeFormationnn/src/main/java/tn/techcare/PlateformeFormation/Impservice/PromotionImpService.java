package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Promotion;
import tn.techcare.PlateformeFormation.repository.PromotionRepository;
import tn.techcare.PlateformeFormation.service.PromotionService;

@Service
@Transactional
public class PromotionImpService implements PromotionService {

	@Autowired
	private PromotionRepository promotionservice ;
	
	
	@Override
	public List<Promotion> getAllPromotion() {
		// TODO Auto-generated method stub
		return promotionservice.findAll();
		}

}
