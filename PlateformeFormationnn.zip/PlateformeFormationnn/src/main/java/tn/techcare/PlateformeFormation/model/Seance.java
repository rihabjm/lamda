package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Seannce")
public class Seance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int id_seance ;
	 private Time heuredeb  ;
	 private Time heurefin ;
	 
	private int numeroseance  ;
	private Date date ;
	public int getId_seance() {
		return id_seance;
	}
	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "idasalle")
	    private Salle salle  ;
	
	public void setId_seance(int id_seance) {
		this.id_seance = id_seance;
	}
	public Time getHeuredeb() {
		return heuredeb;
	}
	public void setHeuredeb(Time heuredeb) {
		this.heuredeb = heuredeb;
	}
	public Time getHeurefin() {
		return heurefin;
	}
	public void setHeurefin(Time heurefin) {
		this.heurefin = heurefin;
	}
	public int getNumeroseance() {
		return numeroseance;
	}
	public void setNumeroseance(int numeroseance) {
		this.numeroseance = numeroseance;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Salle getSalle() {
		return salle;
	}
	public void setSalle(Salle salle) {
		this.salle = salle;
	}
	
	
	
	}
