package tn.techcare.PlateformeFormation.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.techcare.PlateformeFormation.model.FormationModule;



public interface FormationModuleRepository extends JpaRepository<FormationModule, Integer> {
     List<FormationModule> findFormationModuleByType(String type ) ;
	List<FormationModule> findFormationModuleByEtat(String etat ) ;
	List<FormationModule> findFormationModuleByIntitule(String intitule ) ;
	List<FormationModule> findFormationModuleByDatedebut(Date datedeb ) ;
	List<FormationModule> findFormationModuleByDatefin(Date datefin ) ;
	List<FormationModule> findFormationModuleByPrix(float prix ) ;
    List<FormationModule> findFormationModuleByNombreheure(int nombreheure ) ;
    List<FormationModule> findFormationModuleBySession(String session ) ;


}
