package tn.techcare.PlateformeFormation.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
 
@Entity
@Table(name = "certificat")
public class Certificats {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_C ;
	private String intitule ;
	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "idFormateur")
	    private Formateur formateur ;
	 
	 @OneToOne(fetch = FetchType.LAZY,
	            cascade =  CascadeType.ALL,
	            mappedBy = "certificats")
	    private Formation formation;
	 

	public String getIntitule() {
		return intitule;
	}

	public void setIntitule(String intitule) {
		this.intitule = intitule;
	}

	public int getId_C() {
		return id_C;
	}

	public void setId_C(int id_C) {
		this.id_C = id_C;
	}

	public Formateur getFormateur() {
		return formateur;
	}

	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}
	
	

	public Formation getFormation() {
		return formation;
	}

	public void setFormation(Formation formation) {
		this.formation = formation;
	}
	
	

	@Override
	public String toString() {
		return "Certificats [id_C=" + id_C + ", intitule=" + intitule + ", formateur=" + formateur + "]";
	}
	
	
	
	
}
