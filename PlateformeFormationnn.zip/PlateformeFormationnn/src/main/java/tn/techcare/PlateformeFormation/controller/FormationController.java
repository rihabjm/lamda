package tn.techcare.PlateformeFormation.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.FormationService;


@CrossOrigin("*")
@RestController
@RequestMapping("/formation")
public class FormationController {
	@Autowired
	private  FormationService formationService ;
	
	@PostMapping("/add")
	private MessageReponse ajouterreunion (@RequestBody Formation formation) {
		return formationService.ajoutFormation(formation);
	}
	
  @GetMapping("/get")
  private List<Formation> getallformation()
  {
	  
	  return formationService.getAllFormation();
  }
}
