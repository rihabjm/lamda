package tn.techcare.PlateformeFormation.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import tn.techcare.PlateformeFormation.model.Participant;
 
public interface ParticipantRepository extends JpaRepository<Participant,Integer>{
	List<Participant> findParticipantByNom(String nom ) ;
	List<Participant> findParticipantByPrenom(String prenom ) ;
	List<Participant> findParticipantByAdresse(String adresse ) ;
	List<Participant> findParticipantByMail(String mail ) ;
	List<Participant> findParticipantByDateNAisse(Date datenais ) ;
	List<Participant> findParticipantByTelephone(int telephone );

}

