package tn.techcare.PlateformeFormation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.Config.JwtResponse;
import tn.techcare.PlateformeFormation.Config.JwtTokenUtil;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.service.UtilisateurService;

@CrossOrigin
@RestController
public class AuthController {
	


	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired 
	private UtilisateurService utilisateurservice ; 
	
	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	



@PostMapping( "/authenticate")
public ResponseEntity<?> createAuthenticationToken(@RequestBody Utilisateur authenticationRequest ) throws Exception {
	System.out.println(authenticationRequest.getLogin() + authenticationRequest.getMdp());
	authenticate(authenticationRequest.getLogin(), authenticationRequest.getMdp());
	UserDetails userDetails =	utilisateurservice.loadUserByUsername(authenticationRequest.getLogin());
 String token =  jwtTokenUtil.generateToken(userDetails);
return ResponseEntity.ok(new JwtResponse(token));
}	
	
private void authenticate(String username, String password) throws Exception {
try {
	authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
} catch (DisabledException e) {
throw new Exception("USER_DISABLED", e);
} catch (BadCredentialsException e) {
throw new Exception("INVALID_CREDENTIALS", e);
}
	/*
	@PostMapping("/login")
	private boolean auth (@RequestParam("login") String login , @RequestParam("mdp") String mdp ) {
		
		UserDetails m =	membreService.loadUserByUsername(login);
	if(m!=null) {
		System.out.println(passwordEncoder.encode(mdp));
		System.out.println(m.getPassword());
		return passwordEncoder.matches(mdp,m.getPassword()) ;
		
	}
	return false ;
	}*/
}

}
