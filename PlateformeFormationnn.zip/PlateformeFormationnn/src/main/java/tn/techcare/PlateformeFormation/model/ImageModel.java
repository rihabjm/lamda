package tn.techcare.PlateformeFormation.model;
import javax.persistence.*;
 
@Entity
 
@Table(name = "image_table")
 
public class ImageModel {
 
 
  public ImageModel() {
 
        super();
}
   public ImageModel(String name, String type, byte[] picByte) {
 
        this.name = name;
 
        this.type = type;
 
        this.picByte = picByte;
}
    
 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;
 
    @Column(name = "name")
 
    private String name;
 
    @Column(name = "type")
 
    private String type;
 
    @Column(name = "picByte", length = 1000)
 
    private byte[] picByte;
    @OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "image")
    private Utilisateur utilisateur;

    @OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "image")
    private Formation formation;
		
 
    public String getName() {
 
        return name;
}
    public void setName(String name) {
 
        this.name = name;
}
    public String getType() {
 
        return type;
}
   public void setType(String type) {
 
        this.type = type;
}
    public byte[] getPicByte() {
 
        return picByte;
}
    public void setPicByte(byte[] picByte) {
 
       this.picByte = picByte;
 
    }
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Utilisateur getUtilisateur() {
		return utilisateur;
	}
	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}
	public Formation getFormation() {
		return formation;
	}
	public void setFormation(Formation formation) {
		this.formation = formation;
	}
 
    
}