package tn.techcare.PlateformeFormation.controller;


import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Participant;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.service.SessionService;

@CrossOrigin("*")
@RestController
@RequestMapping("/Session")
public class SessionController {

	@Autowired
	private  SessionService sessionservice ;
	
	@PostMapping("/add")
	public MessageReponse ajoutersession (@RequestParam Date datedebut, Date datefin , int nombrepartcipant,Formation formation ,List<Participant>  participants  ){
	    
		return sessionservice.AjouterSession(datedebut, datefin, nombrepartcipant, formation, participants);
	}
	
	@GetMapping("/get")
	public List<Session>getAllSession()
	{
		
     return sessionservice.getAllSession();
		
	}
	
	@PutMapping("/update")
	private MessageReponse updateSession (@RequestBody Session  session ) {
		return sessionservice.ModifierSession(session);
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletSession (@PathVariable("id") int id) {
		return sessionservice.SupprimerSession(id);
		
	}
	
	
	
	
	

}
