package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.service.UtilisateurService;
@Transactional
@Service
public class UtilisateurImpService implements UtilisateurService
{

	@Override
	public List<Utilisateur> getutilisateur() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDetails loadUserByUsername(String login) {
		// TODO Auto-generated method stub
		return null;
	}

}
