package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.util.List;


import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;   
import tn.techcare.PlateformeFormation.model.Participant;
import tn.techcare.PlateformeFormation.model.Session;

public interface SessionService {
	
	 public MessageReponse AjouterSession (Date  datedebut,Date datefin,int nombrepartcipant ,Formation formation ,List<Participant> participants) ;
	  public List<Session> getAllSession();
	  public MessageReponse ModifierSession(Session session) ;
	  public MessageReponse SupprimerSession(int id_session);
	
}
