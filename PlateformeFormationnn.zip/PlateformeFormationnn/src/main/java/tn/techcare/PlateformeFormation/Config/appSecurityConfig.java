package tn.techcare.PlateformeFormation.Config;

public class appSecurityConfig {

}
