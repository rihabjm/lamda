package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.util.List;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface FormationMetiersService {
	public MessageReponse ajoutFormation(String intitule, String duree ,float prix  ,String etat , String type, Date datedebut ,Date datefin ,String description ,ImageModel image) ;
	public List<FormationMetiers>getAllFormation();
	
	public MessageReponse updateFormation(FormationMetiers formation) ;
	public MessageReponse supprimerFormation( int id);
	public List<FormationMetiers> getformationbytype(String type ) ;
	
	public List<FormationMetiers> getformationbyEtat(String etat ) ;

	public List<FormationMetiers> getformationbyintitule(String intitule ) ;
	public List<FormationMetiers> getformationbydatedebut(Date datedeb ) ;
	public List<FormationMetiers> getformationbydatefin(Date datefin ) ;
	public List<FormationMetiers> getformationbyPrix(float prix ) ;
	

	

	
	
}
