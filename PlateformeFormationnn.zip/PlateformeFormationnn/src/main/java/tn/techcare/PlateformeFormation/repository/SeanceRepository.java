package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.Seance;


public interface SeanceRepository extends JpaRepository<Seance,Integer> {

}
