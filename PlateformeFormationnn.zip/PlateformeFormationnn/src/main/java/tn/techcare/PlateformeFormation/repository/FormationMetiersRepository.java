package tn.techcare.PlateformeFormation.repository;
import java.sql.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import tn.techcare.PlateformeFormation.model.FormationMetiers;



public interface FormationMetiersRepository extends JpaRepository<FormationMetiers, Integer> {
	
	List<FormationMetiers> findFormationMetiersByType(String type ) ;
	List<FormationMetiers> findFormationMetiersByEtat(String etat ) ;
	List<FormationMetiers> findFormationMetiersByIntitule(String intitule ) ;
	List<FormationMetiers> findFormationMetiersByDatedebut(Date datedeb ) ;
	List<FormationMetiers> findFormationMetiersByDatefin(Date datefin ) ;
	List<FormationMetiers> findFormationMetiersByPrix(float prix ) ;


}
