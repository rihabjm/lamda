package tn.techcare.PlateformeFormation.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "utilisateur")
public class Utilisateur implements Serializable , UserDetails{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int id ;
	 private String nom ;
	 private String prenom ;
	 private String adresse ;
	 private String mail ;
	 private int telephone ;
	 private String login ;
	 private String mdp ;
	 private Date dateNAisse ; 
 	 

		@OneToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "id_image")
	    private ImageModel image;
	  
		
		
	public ImageModel getImage() {
			return image;
		}
		public void setImage(ImageModel image) {
			this.image = image;
		}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public Date getDateNAisse() {
		return dateNAisse;
	}
	public void setDateNAisse(Date dateNAisse) {
		this.dateNAisse = dateNAisse;
	}
 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getTelephone() {
		return telephone;
	}
	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getMdp() {
		return mdp;
	}
	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	@Override
	public String toString() {
		return "Utilisateur [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", adresse=" + adresse + ", mail="
				+ mail + ", telephone=" + telephone + ", login=" + login + ", mdp=" + mdp + ", dateNAisse=" + dateNAisse
				+  "]";
	}
	 
	 
	@JsonIgnore
	@Override
	public java.util.Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
			
			java.util.Collection<GrantedAuthority> authorities = new ArrayList<>();
	// return	Collections.singleton(new SimpleGrantedAuthority("USER"));
			if (this instanceof Utilisateur) {

				authorities.add(new SimpleGrantedAuthority("ROLE_Admin"));
				
			}
			if (this instanceof Formateur) {
				authorities.add(new SimpleGrantedAuthority("ROLE_formateur"));
				}
	if (this instanceof Participant) {
					authorities.add(new SimpleGrantedAuthority("ROLE_formateur"));
				}
			
		
			return authorities;
	}
	@JsonIgnore
	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return getMdp();
	}
	@JsonIgnore
	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return getLogin();
	}
	@JsonIgnore
	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	@JsonIgnore
	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}
	@JsonIgnore
	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	@JsonIgnore
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}


}
